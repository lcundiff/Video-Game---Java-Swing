
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Game extends Canvas {
	
	// The stragey that allows us to use accelerate page flipping  
	private BufferStrategy strategy;
	// True if the game is currently "running", i.e. the game loop is looping */
	private boolean gameRunning = true;
	//  The list of all the entities that exist in our game 
	private ArrayList entities = new ArrayList();
	// The list of entities that need to be removed from the game this loop */
	private ArrayList removeList = new ArrayList();
	//  The entity representing the player */
	private Entity catHead;
	private Entity shot;
	//  The speed at which the player's catHead should move (pixels/sec) */
	private double moveSpeed = 300;
	//  rotation variable of cat head */
	private double rotateSpeed = 5;	
	// The time at which last fired a shot */
	private long lastFire = 0;
	//  The interval between our players shot (ms) */
	private long firingInterval = 500;
	/** The number of rats left on the screen */
	private int ratCount;
	
	public int width = 750 ; 
	public int height = 570 ;
	
	/** The message to display which waiting for a key press */
	private String message = "";
	/** boolean variable for starting gameplay */
	private boolean waitingForKeyPress = true;
	// True if the left cursor key is currently pressed */
	private boolean leftPressed = false;
	// True if the right cursor key is currently pressed */
	private boolean rightPressed = false;
	// True if we are firing */
	private boolean firePressed = false;
	// True if game logic needs to be applied this loop, normally as a result of a game event */
	private boolean logicRequiredThisLoop = false;
	
	/**
	 * Construct our game and set it running.
	 */
	public Game() {
		// create a frame to contain our game
		JFrame container = new JFrame("Feline Defense");
		
		/** 
		 * Set panel settings
		 **/
		JPanel panel = (JPanel) container.getContentPane();
		panel.setPreferredSize(new Dimension(800,600));
		panel.setLayout(null);
		
		// setup our canvas size and put it into the content of the frame
		setBounds(0,0,800,600);
		panel.add(this);
		
		// Tell AWT not to bother repainting our canvas since we're
		// going to do that our self in accelerated mode
		setIgnoreRepaint(true);
		
		// finally make the window visible 
		container.pack();
		container.setResizable(false);
		container.setVisible(true);
		
		// add a listener to respond to the user closing the window. If they
		// do we'd like to exit the game
		container.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		
		// add a key input system (defined below) to our canvas
		// so we can respond to key pressed
		addKeyListener(new KeyInputHandler());
		
		// request the focus so key events come to us
		requestFocus();

		// create the buffering strategy which will allow AWT
		// to manage our accelerated graphics
		createBufferStrategy(2);
		strategy = getBufferStrategy();
		
		// initialise the entities in our game so there's something
		// to see at startup
		initEntities();
	}
	
	/**
	 * 
	 * Start a new game
	 * 
	 */
	private void startGame() {
		// clear out any existing entities and intialise a new set
		entities.clear();
		initEntities();
		
		// blank out any keyboard settings we currently have
		leftPressed = false;
		rightPressed = false;
		firePressed = false;
	}
	

	private void initEntities() {
		// declare entities
		catHead = new catEntity(this,"sprites/catHead.png",370,530);
		shot = new ShotEntity(this,"sprites/shot.gif",catHead.getX()+10,catHead.getY()-20);
		
		// add cathead
		entities.add(catHead);
		
		// create a block of rats 
		ratCount = 0;
		for (int row=0;row<5;row++) {
			for (int x=0;x<20;x++) {
				Random pos = new Random();
				x = pos.nextInt(width-50); 
				if(x<0) {
					x = 10 ;
				}
				int y = pos.nextInt(10);
				Entity rat = new ratEntity(this,"sprites/rat.PNG",x,y);
				entities.add(rat);
				ratCount++;
			}
		}
	}
	
	/**
	 * 
	 * 
	 * Notifications
	 * 
	 * 
	 */
	public void updateLogic() {
		logicRequiredThisLoop = true;
	}
	
	/**
	 * Remove an entity from the game. The entity removed will
	 * no longer move or be drawn.
	 */
	public void removeEntity(Entity entity) {
		removeList.add(entity);
	}
	
	/**
	 * Notification that the player has died. 
	 */
	public void notifyDeath() {
		message = "Oh no! They got you, try again?";
		waitingForKeyPress = true;
	}
	
	/**
	 * Notification that the player has won since all the rats
	 * are dead.
	 */
	public void notifyWin() {
		message = "Well done! You Win!";
		waitingForKeyPress = true;
	}
	
	/**
	 * Notification that an rat has been killed
	 */
	public void notifyratKilled() {
		// reduce the ratt count, if there are none left, the player has won!
		ratCount--;
		
		if (ratCount == 0) {
			notifyWin();
		}
		
		// if there are still some rats left then they all need to get faster, so
		// speed up all the existing rats
		for (int i=0;i<entities.size();i++) {
			Entity entity = (Entity) entities.get(i);
			
			if (entity instanceof ratEntity) {
				// speed up by 2%
				entity.setHorizontalMovement(entity.getHorizontalMovement() * 1.02);
			}
		}
	} // rat killed method
	
	
	/**
	 * 
	 * fire method
	 * 
	 */
	public void tryToFire() {
		// check that we have waiting long enough to fire
		if (System.currentTimeMillis() - lastFire < firingInterval) {
			return;
		}
		
		// if we waited long enough, create the shot entity, and record the time.
		lastFire = System.currentTimeMillis();
		ShotEntity shot = new ShotEntity(this,"sprites/shot.gif",catHead.getX()+10,catHead.getY()-20);
		entities.add(shot);
	}
	
	
	public void gameLoop() {
		long lastLoopTime = System.currentTimeMillis();
		
		// keep looping round til the game ends
		while (gameRunning) {
			// work out how long its been since the last update, this
			// will be used to calculate how far the entities should
			// move this loop
			Random ranNum = new Random() ;
			// calc delta as time diff between last frame and this frame
			long delta = System.currentTimeMillis() - lastLoopTime;
			lastLoopTime = System.currentTimeMillis();
			
			/**
			 * 
			 * Make background
			 * 
			 */
			Graphics2D g2d	 = (Graphics2D) strategy.getDrawGraphics();
			Image sourceImage = null;
			// lets generate the background
			try {
				URL url = this.getClass().getClassLoader().getResource("sprites/back_small.png");
				if (url == null) {
					System.out.print("Can't find ref: ");
				}
				sourceImage = ImageIO.read(url);
				
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			 
			sourceImage = sourceImage.getScaledInstance(width+60, height+30, Image.SCALE_DEFAULT);
			g2d.drawImage(sourceImage, 0, 0, null);
			
			// cycle round asking each entity to move itself
			if (!waitingForKeyPress) { // if game has started
				for (int i=0;i<entities.size();i++) {
					Entity entity = (Entity) entities.get(i); // entity object cast of get entities
					double changePath = ranNum.nextInt(2)-1; 
					delta += changePath ;
					entity.move(delta) ;
				}
			}
			
			// cycle round drawing all the entities we have in the game
			for (int i=0;i<entities.size();i++) {
				Entity entity = (Entity) entities.get(i);
				entity.draw(g2d,catHead.sprite);
			}
			
			// brute force collisions, compare every entity against
			// every other entity. If any of them collide notify 
			// both entities that the collision has occured
			for (int p=0;p<entities.size();p++) {
				for (int s=p+1;s<entities.size();s++) {
					Entity me = (Entity) entities.get(p);
					Entity him = (Entity) entities.get(s);
					
					if(me.collidesWith(him)) {
						me.collidedWith(him);
						him.collidedWith(me);
					}
				}
			}
			
			// remove any entity that has been marked for clear up
			entities.removeAll(removeList);
			removeList.clear();

			/** 
			 *  Game logic
			**/
			if (logicRequiredThisLoop) {
				for (int i=0;i<entities.size();i++) {
					Entity entity = (Entity) entities.get(i);
					entity.doLogic();
				}
				
				logicRequiredThisLoop = false;
			}
			
			// if we're waiting for an "any key" press then draw the 
			// current message 
			if (waitingForKeyPress) {
				g2d.setColor(Color.white);
				g2d.drawString(message,(800-g2d.getFontMetrics().stringWidth(message))/2,250);
				g2d.drawString("Press any key",(800-g2d.getFontMetrics().stringWidth("Press space key"))/2,300);
			}
			
			// finally, we've completed drawing so clear up the graphics
			// and flip the buffer over
			g2d.dispose();
			strategy.show();
			
			// resolve the movement of the catHead. First assume the catHead 
			// isn't moving. If either cursor key is pressed then
			// update the movement appropraitely
			catHead.setHorizontalMovement(0);
			/*
			if ((leftPressed) && (!rightPressed)) {
				catHead.setHorizontalMovement(-moveSpeed);
			} else if ((rightPressed) && (!leftPressed)) {
				catHead.setHorizontalMovement(moveSpeed);
			}
			*/
			
			
			// rotate sprite
			if ((leftPressed) && (!rightPressed)) {
				shot.rotate(-rotateSpeed,g2d, catHead);
				catHead.rotate(-rotateSpeed,g2d, catHead); // it calls rotate method in Entity class with -10 for each key pressed
			} else if ((rightPressed) && (!leftPressed)) {
				shot.rotate(rotateSpeed,g2d,catHead);
				catHead.rotate(rotateSpeed,g2d,catHead);
			}	
			
			// if we're pressing fire, attempt to fire
			if (firePressed) {
				tryToFire();
			}
			
			// finally pause for a bit. Note: this should run us at about
			// 100 fps but on windows this might vary each loop due to
			// a bad implementation of timer
			try { Thread.sleep(10); } catch (Exception e) {}
		}
	}
	
	/**
	 * A class to handle keyboard input from the user. The class
	 * handles both dynamic input during game play, i.e. left/right 
	 * and shoot, and more static type input (i.e. press any key to
	 * continue)
	 * 
	 * This has been implemented as an inner class more through 
	 * habbit then anything else. Its perfectly normal to implement
	 * this as seperate class if slight less convienient.
	 * 
	 */
	private class KeyInputHandler extends KeyAdapter {
		/** The number of key presses we've had while waiting for an "any key" press */
		private int pressCount = 1;
		
		/**
		 * Notification from AWT that a key has been pressed. Note that
		 * a key being pressed is equal to being pushed down but *NOT*
		 * released. Thats where keyTyped() comes in.
		 *
		 * @param e The details of the key that was pressed 
		 */
		public void keyPressed(KeyEvent e) {
			// if we're waiting for an "any key" typed then we don't 
			// want to do anything with just a "press"
			if (waitingForKeyPress) {
				return;
			}
			
			
			if (e.getKeyCode() == KeyEvent.VK_LEFT) {
				leftPressed = true;
			}
			if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
				rightPressed = true;
			}
			if (e.getKeyCode() == KeyEvent.VK_SPACE) {
				firePressed = true;
			}
		} 
		
		/**
		 * Notification from AWT that a key has been released.
		 *
		 */
		public void keyReleased(KeyEvent e) {
			// if we're waiting for an "any key" typed then we don't 
			// want to do anything with just a "released"
			if (waitingForKeyPress) {
				return;
			}
			
			if (e.getKeyCode() == KeyEvent.VK_LEFT) {
				leftPressed = false;
			}
			if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
				rightPressed = false;
			}
			if (e.getKeyCode() == KeyEvent.VK_SPACE) {
				firePressed = false;
			}
		}

		public void keyTyped(KeyEvent e) {
			// if we're waiting for a "any key" type then
			// check if we've recieved any recently. We may
			// have had a keyType() event from the user releasing
			// the shoot or move keys, hence the use of the "pressCount"
			// counter.
			if (waitingForKeyPress) {
				if (pressCount == 1) {
					// since we've now recieved our key typed
					// event we can mark it as such and start 
					// our new game
					waitingForKeyPress = false;
					startGame();
					pressCount = 0;
				} else {
					pressCount++;
				}
			} // 
			
			// if we hit escape, then quit the game
			if (e.getKeyChar() == 27) {
				System.exit(0);
			}
		}
	}
	
	/**
	 * How game starts. 
	 */
	public static void main(String argv[]) {
		Game g =new Game();
		// Start the main game loop, note: this method will not
		// return until the game has finished running. Hence we are
		// using the actual main thread to run the game.
		
		Menu m = new Menu(); 
		//m.menuLoop(); 

		g.gameLoop();
	}
}

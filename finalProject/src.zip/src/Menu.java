import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;

public class Menu {
	
	private boolean menuRunning = true;
	private boolean shop = false;
	private int width = 750 ; private int height = 570 ;
	private int x = 0; int y = 0;
	
	public void menuLoop() {
		long lastLoopTime = System.currentTimeMillis(); // start a menu timer just cuz
		/**
		 * menu will run until we quit or go into the shop menu
		 */
		while (menuRunning && !shop) { 
			BufferedImage menu = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			Graphics2D g2d	 = menu.createGraphics(); // make graphics object
			g2d.drawRect(x, y, width, height);
			g2d.setColor(Color.BLUE);
			g2d.fillRect(x, y, width, height);
			
			g2d.drawRect(width/2, height/2, 70, 50);
			g2d.setColor(Color.MAGENTA);
			g2d.fillRect(width/2, height/2, 70, 50);
			g2d.drawImage(menu, 0,0,null);
		}
			
		
	}
		
}

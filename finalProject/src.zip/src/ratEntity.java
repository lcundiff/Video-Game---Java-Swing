import java.util.Random;


public class ratEntity extends Entity {
	// The speed at which the ratt moves horizontally */
	private double moveSpeed = 75;
	// The game in which the entity exists */
	private Game game;
	int count = 0;
	public ratEntity(Game game,String ref,int x,int y) {
		super(ref,x,y,0);
		
		this.game = game;
		dx = -moveSpeed;
	}

	public void move(long delta) {
		Random rand = new Random(); 
		 count++ ;
		// if we have reached the left hand side of the screen and
		// are moving left then request a logic update 
		if(count > 50) {
			dx = rand.nextInt(200)-100 ;
			y+=8; 
			count = 0; 
		}
		if ((dx < 0) && (x < 10)) {
			game.updateLogic();
		}
		//dy+= rand.nextDouble(); 
		// and vice vesa, if we have reached the right hand side of 
		// the screen and are moving right, request a logic update
		if ((dx > 0) && (x > 750)) {
			game.updateLogic();
		}
		
		// proceed with normal move
		super.move(delta);
	}
	
	/**
	 * Update the game logic related to rats
	 */
	public void doLogic() {
		// swap over horizontal movement and move down the
		// screen a bit
		dx = -dx;
		y += 1;
		
		// if we've reached the bottom of the screen then the player
		// dies
		if (y > 570) {
			game.notifyDeath();
		}
	}
	
	/**
	 * Notification that this rat has collided with another entity
	 * 
	 * @param other The other entity
	 */
	public void collidedWith(Entity other) {
		// collisions with rats are handled elsewhere
	}
}